<?php

define('DB_HOST', 'localhost');
define('DB_PORT', 8889); // default 3306
define('DB_USER', 'esgi');
define('DB_PWD', 'esgi75012');
define('DB_NAME', 'ffw');
define('DB_LOG', true);
define('SALT_KEY', "-FFW_75~#")

?>

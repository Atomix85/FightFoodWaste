/**
* \file file_json.c
* \author Kimia K.
* \version 1.0
* \date 01/06/2019
*
* Fichier contenant le parse json
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../datas/commons_datas.h"
#define POST_REQUEST    1

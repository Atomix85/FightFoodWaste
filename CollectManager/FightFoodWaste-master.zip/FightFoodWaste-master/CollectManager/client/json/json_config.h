
/* Define to 1 if you have the <inttypes.h> header file. */
#if defined(_MSC_VER) && _MSC_VER >= 1800
#define JSON_C_HAVE_INTTYPES_H 1
#endif

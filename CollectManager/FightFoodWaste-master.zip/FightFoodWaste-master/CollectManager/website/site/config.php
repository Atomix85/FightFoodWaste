<?php
$bdd = new PDO('mysql:host=localhost;dbname=projetAnnuel;charset=utf8', 'root', 'root');
?>
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.table.AbstractTableModel;

public class Tab extends AbstractTableModel {
	private Object[][] data;
	private String[] title;
	private static String url ="jdbc:mysql://localhost:8889/ffw";
	private static String login = "root"; 
	private static String passwd = "root";
	private static Connection connexion =null;
	private static Statement state =null;
	
	public Tab(Object[][] data, String[] title){
		this.data = data;
		this.title = title;
		}

	public String getColumnName(int col) {
		return this.title[col];}
	
	public int getColumnCount() {
		return this.title.length;
	}
	public int getRowCount() {
		return this.data.length;
	}
	public Object getValueAt(int row, int col) {
		return this.data[row][col];
	}
	
	public Class getColumnClass(int col){
		return this.data[0][col].getClass();
	}

	public void removeRow(int position){
		int indice = 0, indice2 = 0;
		int nbRow = this.getRowCount()-1, nbCol = this.getColumnCount();
		Object temp[][] = new Object[nbRow][nbCol];
		for(Object[] value : this.data){
			if(indice != position){
				temp[indice2++] = value;
			}
			System.out.println("Indice = " + indice);
			indice++;
		}
		this.data = temp;
		temp = null;
		this.fireTableDataChanged();
	}

	public void addRow(Object[] data) throws SQLException, ClassNotFoundException{
		int indice = 0, nbRow = this.getRowCount(), nbCol = this.getColumnCount();
		
		Object temp[][] = this.data;
		this.data = new Object[nbRow+1][nbCol];
		for(Object[] value : temp)
		this.data[indice++] = value;
		this.data[indice] = data;
		temp = null;
		
		
		Connexion();
		state = connexion.createStatement();
		ResultSet result = state.executeQuery("INSERT INTO Menu VALUES (test,"+this.data[1]+","+this.data[2]+","+this.data[0]+",0,0) ");
		//System.out.println("Ajout réussi dans la base");
		
		this.fireTableDataChanged();
		
	}
	
	 public boolean isCellEditable(int row, int col){
	      return true;
	   }
	 
	 public static void Connexion() throws SQLException, ClassNotFoundException {
			Class.forName("com.mysql.jdbc.Driver");
			connexion = DriverManager.getConnection(url,login,passwd);
		
		}
	
}

